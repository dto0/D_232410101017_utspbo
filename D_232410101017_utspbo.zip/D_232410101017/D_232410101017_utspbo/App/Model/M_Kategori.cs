﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D_232410101017_utspbo.App.Model
{
    internal class M_Kategori
    {
        [Key]
        public int id { get; set; }
        [Required]
        public string kategori { get; set; }
    }
}
