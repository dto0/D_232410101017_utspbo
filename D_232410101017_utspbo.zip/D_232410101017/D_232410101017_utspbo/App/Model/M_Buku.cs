﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D_232410101017_utspbo.App.Model
{
    internal class Class_Buku
    {
        [Key]
        public int id { get; set; }
        [Required]
        public string judul { get; set; }
        [Required]
        public string pengarang { get; set; }
        [Required]
        public int tahun_terbit { get; set; }
        [ForeignKey("M_Kategori")]
        public int id_kategori { get; set; }

    }
}
